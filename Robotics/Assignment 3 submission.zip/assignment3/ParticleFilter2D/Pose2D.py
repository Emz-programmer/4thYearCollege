from shutil import move
import numpy as np

class Pose2D:
    """Helper class containing a number static methods for creating and manipulating 2D poses"""

    @staticmethod
    def randomPoses(num_poses, worldsize):
        """Generates a numpy array of random poses

        Args:
            num_poses (int): number of poses to generate
            worldsize  (float): specifies dimensions of the world (i.e. the 
                maximum values for the pose x and y values).
        
        Returns:
            np.array: Nx3 numpy array of generated poses where each pose contains the pose's
                [x, y, theta] values where theta is stored in radians.
        """
        return np.array((np.random.uniform(0.0, worldsize, num_poses),
                np.random.uniform(0.0, worldsize, num_poses),
                np.random.uniform(-np.pi, np.pi, num_poses))).T

    @staticmethod
    def originPoses(num_poses, worldsize):
        """Generates a numpy array of zero poses (i.e. all having the values [0, 0, 0])

        Args:
            num_poses (int): number of poses to generate
            worldsize  (float): specifies dimensions of the world (i.e. the 
                maximum values for the pose x and y values).
        
        Returns:
            np.array: Nx3 numpy array of generated poses where each pose contains the pose's
                [x, y, theta] values where theta is stored in radians.
        """
        return np.tile(
            np.array([worldsize/2.0, worldsize/2.0, np.pi/2]),
            (num_poses,1))
   
    @staticmethod
    def computePose(pose, odometry):
        #Move the pose distance at theta degrees
        theta = odometry[2]+pose[2]
        rotationMatrix = np.array((
            (np.cos(theta), -np.sin(theta), 0),
            (np.sin(theta), np.cos(theta), 0),
            (0,0,1)
        ))
        #print("Rotate dot Odem", rotationMatrix.dot(odometry))
        pose = pose+(rotationMatrix.dot(odometry))
        #normalise the angle
        pose[2] = Pose2D.normaliseAngle(pose[2])
        # return the updated pose
        return pose

    @staticmethod
    def addOdometry(poses, odometry):
        """Applies odometry to input poses

        Applies the (non-probabilistic / deterministic) kinematic motion model from the
        CS427 particle filter notes by propagating the set of input poses according to 
        the input odometry. 

        Args:
            poses (np.array): Nx3 numpy array of poses where each pose contains the pose's
                [x, y, theta] values where theta is stored in radians.
            odometry (np.array): 1x3 or Nx3 numpy array of odometry parameters [dx, dy, dtheta].
                If the the structure is 1x3 it applies the same odometry to all
                poses. If the structure is Nx3 the i'th vector in odometry is applied
                to the i'th vector in poses.

        Returns:
            np.array: Nx3 numpy array of updated poses where each pose contains the pose's
                [x, y, theta] values where theta is stored in radians. 
        """        

        ## STEP 1: Implement the transformation to apply the odometry to the
        ##          inputted poses. WARNING: Note that when you compute the 
        ##          final orientation you should normalise its value. This 
        ##          can be done by using the Pose2D.normaliseAngle function below.
        #poses = x t-1
        #odometry = ut
        #print("Odom shape",odometry.shape)
        if odometry.shape==(3,):
            # used for the red guy
            #print("One odometry")
            counter =0
            for pose in poses:
                pose = Pose2D.computePose(pose, odometry)
                poses[counter]=pose
                counter = counter +1
            return poses
        else:
            # used for the 150 other poses
            #print("Many odometry")
            counter =0
            for pose,movement in zip(poses, odometry):
                #print("Movement",movement)
                #print("Pose",pose)
                pose = Pose2D.computePose(pose, movement)
                poses[counter]=pose
                counter = counter +1
            return poses 

        

            

    @staticmethod
    def normaliseAngle(angle):
        """Normalises the input angle to the range ]-pi/2, pi/2]"""        
        if ((angle < np.pi) and (angle >= -np.pi)):
            return angle
        pi2 = np.pi*2
        nangle = angle - (int(angle/(pi2))*(pi2))
        if (nangle >= np.pi):
            return nangle - pi2
        elif (nangle < -np.pi):
            return nangle + pi2
        return nangle 