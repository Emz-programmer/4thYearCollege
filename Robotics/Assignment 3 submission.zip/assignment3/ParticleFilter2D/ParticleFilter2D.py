import numpy as np

from ParticleFilter2D.Pose2D import Pose2D
from ParticleFilter2D.MotionModel import MotionModel
from ParticleFilter2D.SensorModel import SensorModel

class ParticleFilter2D:
    """2D (i.e. 3-DoF) Particle Filter.

    Implements the 2D particle filtering algorithm covered during CS427
    and in Thrun et al. Ch4 and Ch8.

    Attributes:
        worldsize (float): size of x and y world dimensions
        poses (array): Nx3 numpy array of particle poses where each pose contains
            the pose's [x, y, theta] values, where theta is stored in radians.
        weights (array): numpy array of N importance particle weights
        motionModel (MotionModel): see MotionModel
        sensorModel (SensorModel): see SensorModel
    """

    def __init__(self, num_particles=50, worldsize = 750):
        """Instantiates a new ParticleFilter2D with num_particles and a worldsize.

        Create a new ParticleFilter2D object containing num_particles particles
        and operating of the size worldsize.

        Args:
            num_particles (int): Number of particles to use in the filter 
                (default: 50).
            worldsize (float): Size of the world in x and y dimensions
                (default: 750).
        """
        self.worldsize = worldsize
        self.poses = Pose2D.randomPoses(num_particles, worldsize)
        self.weights = np.ones((num_particles), dtype=float)/num_particles

        self.motionModel = MotionModel()
        self.sensorModel = SensorModel()

    def processFrame(self, odometry, measurements, landmarks):
        """Perform a single predict, update, resample iteration.

        Args:
            odometry (array): 1x3 numpy array of odometry parameters 
                [dx, dy, dtheta] 
            measurements (list): list of SensorMeasurements.
            landmarks (array): Nx2 array of landmark [x, y] location vectors.            
        """
        self.processMotion(odometry)
        self.processSensor(measurements,landmarks)

        self.resample()

    def processSensor(self, measurements, landmarks):
        """Process sensor measurements and update weights.

        Performs updated step of the particle filtering algorithm.
        
        Args:
            measurements (list): list of SensorMeasurements.
            landmarks (array): Nx2 array of landmark [x, y] location vectors.
        """        

        ## STEP 5: Add code here that computes the importance weights
        ##          for each pose by calling the relevant method from
        ##          SensorModel 
        
        for i, (pose) in enumerate(zip(self.poses)): #Set the weight of each pose to be weighted by the sensor data
            self.weights[i] = SensorModel.likelihood(self=self.sensorModel,pose=pose,measurements=measurements,landmarks=landmarks)                        
        self.weights = self.weights/np.linalg.norm(self.weights)
        weightSum = np.sum(self.weights)
        if weightSum>1: # Handles bug where normalised weights greatly exceed 1 for cases where no landmarks visible
            self.weights=self.weights/weightSum
        #print(self.weights)
        #print("Sum: ",np.sum(self.weights))
        


    def processMotion(self, odometry):
        """Process odometry by propagating particles using given odometry.

        Performs prediction step of the particle filtering algorithm.
        
        Args:
            odometry (array): 1x3 numpy array of odometry parameters 
                [dx, dy, dtheta] 
        """                
        self.poses = self.motionModel.propagatePoses(self.poses, odometry)

    def resample(self):
        """Perform resampling step.

        Resample particles by drawing M particles with replacement where each 
        particle has a probability of being selected based on its current
        weight.
        """    
        ## STEP 6: Provide an implementation of the stochastic universal sampling
        ##          algorithm
        #Starting point
        
        w=self.weights        
        
        c= w[0]
        
        xt=np.copy(self.poses) #Copy poses to avoid pass by reference
        #print(xt, "\nOLD POSES")
        M = len(self.poses) 
        i=0
        r= np.random.uniform(0,1/ M)
        #print("Random start weight=",r)
        for m in range (0,M):
            #print("m: ",m)
            u = r+(m/M) # Get next sample weight
            #print("Value of u=",u,"Value of c=",c)
            while u>c and i<M-1: # While sample weight is greater than weight c, set weight c to weight[i+1]
                #print("finding weight, index i=", i)
                i=i+1
                c=c+w[i]
            xt[m] = self.poses[i] #Add pose i to the mth index of xt (resampled points)
            
        self.poses=xt #set resampled points to self points

        pass


    def __str__(self):
        rstr = '\n'.join(["x: {}, y: {}, angle: {}, weight: {}".format(p[0], p[1], p[2], w)
            for p,w in zip(self.poses.T, self.weights)])
        return rstr 