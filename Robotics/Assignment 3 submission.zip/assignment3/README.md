# CS427 Assignment 3 Monte Carlo Localisation
#### Lecturer: Prof. John McDonald
#### Submission Deadline: See CS427 moodle webpage

## Objectives
The objective of this assignment is to provide you with hands-on experience in 
implementing the main elements of the Monte Carlo Localisation algorithm covered
during the last lecture segment of the Localisation section of the course. In 
this repository you will have a partial implementation of the algorithm 
consisting of a Python package and script that applies the MCL algorithm for 
localisation a virtual 3-DoF robot in a simple simulated environment consisting
of a set point-based landmark.

The code is heavily commented to allow you to gain an understanding of the code
by directly browsing the package and associated classes and methods. To start this
process you should begin by reviewing the `driver.py` file which contains the code
to create the simulated environment, control the robot, and call the relevant 
methods and classes from the `ParticleFilter2D` package. All of the classes and
methods have their comment structured as docstrings and so will provide context
sensitive help within your IDE. 

## Useful Resources
Given that CS422 is a prerequisite to CS427 we do assume that everyone has some experience with python. However in case you need a refresher, or don't have the requisite experience, a very good online tutorial is available at: https://scipy-lectures.github.io/. In particular I would recommend you take some time to go through the first two chapters, providing an intro to python, the third chapter, providing an overview of using numpy, and possibly the fourth chapter on plotting data.  

## Communication & Plagiarism Policy
As with the previous assignments, as you work through the problem set and the related lecture and reading material you are encouraged to use the moodle CS427 class forum, the Microsoft Teams group, or direct email with John McDonald to post and discuss any questions that you have. Note that the teams group and the forum will be monitored for the duration of the assignment for any questions.

However, it is important to note that given that this work will count towards your final mark, the University Plagiarism Policy strictly applies to the assignment. In support of this policy and in order to maintain the integrity of the assessment process, individual students may be required to attend an interview to discuss, explain, and validate their submission.

## Completing the Assignment
As mentioned above, although the code does run, in its current form it simply 
creates the world, displays it, and accepts key presses, but does little else. This
is because although the `driver.py` files calls the correct methods, many of them do not
have the necessary functionality implemented. Your task is to review each class and
where you find comments marked `## STEP XX: ...`, to replace the comment with the 
appropriate code as specified in the comment.

The comments are labelled as a set of ordered steps, as completing each in the 
suggested order will allow you to incrementally build and test individual elements
of functionality. The list below provides a brief description of each
step with further details provide in the commented code. In order to understand the
full requirements for the code, in each step you should closely review the docstring
for the method to clearly understand the type and structure of the input and output
parameters. For example, in each case the dimensions of arrays are provided and need
to be followed strictly.

*NOTE:* As with each of the assignments to date, prior to starting the assignment
you are strongly encouraged to watch the associated lecture segments, and to review
the recommended reading as this will give you the necessary background to correctly
understand and interpret the code.

## Tasks and Marking Scheme
The assignment is optional and is worth 7% of the final grade. That is, your final grade will be a maximum of 
- 14% for the CA based on assignments 1(7%) and 2(7%) and 86% for the final paper, or,
- 21% for the CA based on assignments 1-3(7% each) and 79% for the final paper

The goal here is to ensure that you are not disadvantaged by taking either option. 

The breakdown of marks for each of the steps involved in completing the assignment is as follows:
1. `Pose2D.addOdometry(...)` (`Pose2D.py`) [**6 marks**]: Implement the 
transformation to apply the odometry to the inputted poses
1. `SensorModel.getVisibleLandmarks(...)` (`SensorModel.py`) [**6 marks**]: Add
code to compute the set of visible landmarks
1. `MotionModel.propagatePoses(...)` (`MotionModel.py`) [**6 marks**]:  Implement
the probabilistic motion model (i.e. including noise), as discussed
in the notes
1. `SensorModel.likelihood(...)` (`SensorModel.py`) [**6 marks**]:  Implement the
likelihood model of a set of measurements given the pose and the corresponding landmarks
1. `ParticleFilter2D.processSensor(...)` (`ParticleFilter2D.py`) [**6 marks**]: Add
the code to compute the importance weights for each pose
1. `ParticleFilter2D.resample(...)` (`ParticleFilter2D.py`) [**10 marks**]: Provide an implementation of the stochastic universal sampling algorithm

The video below shows a complete working version of the code where each of the above steps has been completed. In the video the red robot (i.e. circle) represents the ground truth pose, whilst the white circles represent landmarks in the environment. White circles become red when they are sensed by the robot. The blue and purple circles show the particle distribution. As can be seen in the video as the robot traverses featureless regions the particle distribution increases in uncertainty, and then decreases as more observations are made by its sensor. 

[![IMAGE ALT TEXT HERE](https://i.imgur.com/uV6vK2H.jpg)](https://mu.cloud.panopto.eu/Panopto/Pages/Viewer.aspx?id=b719e532-a2dd-4340-8187-ad17014e67d2)

## Setup
Installation and setup is similar to assignment 2 however requires less packages. 
- Install [Miniconda](https://docs.conda.io/en/latest/miniconda.html). Choose your OS and Architecture. _Skip this step if you have anaconda or miniconda already installed_
- Create a conda environment, using the following command. On Windows, open the installed **Conda Prompt** (or **Anaconda Prompt**) to run this command. On MacOS and Linux, you can just use a **terminal** window to run the command.: `conda create -n cs427_hw3`. Confirm the packages marked for installation if prompted.
- This should create an environment named `cs427_hw3`. Activate it using `conda activate cs427_hw3`.
- The navigate to your projects directory (or create one) and then do `git clone https://gitlab.cs.nuim.ie/cs427_2022/assignment3`
- Now install requirements using `pip install -r requirements.txt`
- Now using your favourite IDE start by opening `driver.py`

For convenience, here are all the commands
```sh
conda create -n cs427_hw3
conda activate cs427_hw3

cd projects
git clone https://gitlab.cs.nuim.ie/cs427_2022/assignment3
cd assignment3
pip install -r requirements.txt
```
You can run the `driver.py` file from inside ipython using
```sh
ipython

Python 3.7.6 (default, Jan  8 2020, 20:23:39) [MSC v.1916 64 bit (AMD64)]                                               
Type 'copyright', 'credits' or 'license' for more information                                                           
IPython 7.19.0 -- An enhanced Interactive Python. Type '?' for help. 
In [1]: run ./driver.py 
```

## Coding and Submission guidelines

You should submit your work as a single zip or tar.gz file of the assignment3 folder, where the
file should be submitted through the relevant link on the moodle webpage.  The important
point is that completing the assignment should **not** involve any changes to the code in driver.py and that running your submission
should be through `run ./driver.py` in the `assignment3` folder.

**It is important that in developing your solution:** 
- all code that you add should be contained in the functions/methods and at the locations
of the associated `##STEP XX: ...` comment i.e. please do not alter the overall structure or
layout of the `ParticleFilter2D` library
- **you provide a brief comment with your added code explaining its operation**
- You may use any libraries that are already imported within the given code. For example you may use numpy (e.g. numpy.random for sampling for distributions). You may also use scipy.stats (e.g. scipy.stats.norm.pdf to evaluate likelihoods). **You should not use any other libraries/code that provide functionality to produce desired output.** If you have any queries on this point please feel free to get in touch.
